<template>
  <div>
    <AppHeader />
    <slot />
    
    <AppFooter />
  </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
