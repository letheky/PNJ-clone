//Trang sức
export const NUXT_APP_ACCESSORIES_TYPES = 'Nhẫn,Dây chuyền,Mặt dây chuyền,Bông tai,Lắc,Vòng,Charm,Dây cổ,Kiềng,Vòng tài lộc'
export const NUXT_APP_ACCESSORIES_MATERIALS = 'Vàng,Bạc,Bạch kim'
export const NUXT_APP_ACCESSORIES_LIST = 'Trang sức đính kim cương,Trang sức đính ECZ,Trang sức đá quý và bán quý,Trang sức công nghệ Ý,Trang sức đính CZ,Trang sức đính ngọc trai'
export const NUXT_APP_ACCESSORIES_COLLECTIONS = 'Sunnyvia,Audax Rosa,Share the wonder,Niềm tin,Trầu cau PNJ,Masterpiece,Euphoria,First Diamond,Sweet Hello Kitty,Unisex,The shinning princess,Ariel, DNA Vol 1, DNA Vol 2'

//Trang sức cưới
export const NUXT_APP_WEDD_ACCESS_PURPOSES = 'Cầu hôn, Kết hôn, Kỷ niêm'
export const NUXT_APP_WEDD_ACCESS_TYPES = 'Nhẫn Cặp, Nhẫn, Mặt dây chuyền, Bông tai, Lắc, Vòng Tay, Charm, Dây cổ, Kiềng'
export const NUXT_APP_WEDD_ACCESS_CATEGORIES = 'Kim cương, ECZ - CZ, Không đính đá, Đá màu'
export const NUXT_APP_WEDD_ACCESS_MATERIALS = 'Vàng 24K, Vàng 22K, Vàng 18K, Vàng 14K, Vàng 10K'
export const NUXT_APP_WEDD_ACCESS_COLLECTIONS = 'Trầu cau PNJ, The heart of gold, The Story in your Rings, The Moment, Báu vật phu thê, Hạnh phúc, Long phụng sum vầy, Vũ khúc tình yêu, Thiên duyên, Bốn mùa yêu thương, Hoa tình yêu'

//Đồng hồ

export const NUXT_APP_WATCH_SWED_BRANDS = 'Jowissa , Silvana , Longines, Tissot, Jacques Du Manoir, Claude Bernard'
export const NUXT_APP_WATCH_FASHION_BRANDS = 'Emily Carter , Olivia Burton, Just Cavalli, Kenneth Cole, Avi-8 , Michael Kors, Fossil, Daniel Wellington'
export const NUXT_APP_WATCH_FAVOR_BRANDS = 'Citizen, Casio, Orient, Skagen, Lancaster , Hamilton, Calvin Klein'
export const NUXT_APP_WATCH_ON_GENDERS = 'Nam, Nữ, Unisex'
export const NUXT_APP_WATCH_TYPES = 'Đồng Hồ, Mắt Kính, Đồng Hồ Cặp, Phụ Kiện'
export const NUXT_APP_WATCH_MATERIALS = 'Dây Da, Dây Thép Không Gỉ 316L, Dây Cao Su, Dây Satin, Các Loại Dây Khác'

//Quà tặng

export const NUXT_APP_GIFT_FOR = 'Cho nàng, Cho chàng, Cho cha, Cho mẹ, Cho bé'